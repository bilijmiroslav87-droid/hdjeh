package com.glassmenu;

public final class Settings {
    public static boolean hud = true;
    public static boolean hitParticles = true;
    public static boolean trail = false;
    public static int accentIndex = 0;

    public static final int[] ACCENTS = {
        0xFF7AB8FF, // blue
        0xFFFF6FA8, // pink
        0xFF7CFFB2, // mint
        0xFFFFD36E, // gold
        0xFFC08CFF  // violet
    };
    public static final String[] ACCENT_NAMES = {"Blue", "Pink", "Mint", "Gold", "Violet"};

    public static int accent() {
        return ACCENTS[accentIndex];
    }

    private Settings() {}
}
