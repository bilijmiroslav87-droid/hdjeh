package com.glassmenu;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class GlassScreen extends Screen {
    private static final int PANEL_W = 260;
    private static final int PANEL_H = 230;
    private static final int ROWS = 4;

    public GlassScreen() {
        super(Text.literal("Glass Menu"));
    }

    private int left() { return (width - PANEL_W) / 2; }
    private int top() { return (height - PANEL_H) / 2; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int x = left(), y = top();
        int accent = Settings.accent();

        // dim background
        ctx.fill(0, 0, width, height, 0x66000000);

        // glass panel: base tint, lighter top half for a glossy look, thin border
        ctx.fill(x, y, x + PANEL_W, y + PANEL_H, 0x99101820);
        ctx.fill(x, y, x + PANEL_W, y + PANEL_H / 2, 0x22FFFFFF);
        ctx.fill(x, y, x + PANEL_W, y + 1, 0x55FFFFFF);
        ctx.fill(x, y + PANEL_H - 1, x + PANEL_W, y + PANEL_H, 0x33FFFFFF);
        ctx.fill(x, y, x + 1, y + PANEL_H, 0x33FFFFFF);
        ctx.fill(x + PANEL_W - 1, y, x + PANEL_W, y + PANEL_H, 0x33FFFFFF);

        // title and accent line
        ctx.drawCenteredTextWithShadow(textRenderer, "Glass Menu", width / 2, y + 14, 0xFFFFFFFF);
        ctx.fill(x + 16, y + 30, x + PANEL_W - 16, y + 31, accent);

        // rows
        String[] labels = {"HUD", "Hit particles", "Self trail", "Accent color"};
        String[] values = {
                onOff(Settings.hud),
                onOff(Settings.hitParticles),
                onOff(Settings.trail),
                Settings.ACCENT_NAMES[Settings.accentIndex]
        };
        for (int i = 0; i < ROWS; i++) {
            int ry = rowY(i);
            ctx.fill(x + 16, ry, x + PANEL_W - 16, ry + 28, 0x33FFFFFF);
            ctx.fill(x + 16, ry, x + 18, ry + 28, accent);
            ctx.drawTextWithShadow(textRenderer, labels[i], x + 26, ry + 10, 0xFFFFFFFF);
            int vw = textRenderer.getWidth(values[i]);
            ctx.drawTextWithShadow(textRenderer, values[i], x + PANEL_W - 26 - vw, ry + 10, accent);
        }

        ctx.drawCenteredTextWithShadow(textRenderer, "Click a row to change it", width / 2,
                y + PANEL_H - 22, 0xFFAAAAAA);

        super.render(ctx, mouseX, mouseY, delta);
    }

    private int rowY(int i) {
        return top() + 46 + i * 38;
    }

    private static String onOff(boolean b) {
        return b ? "ON" : "OFF";
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int x = left();
            for (int i = 0; i < ROWS; i++) {
                int ry = rowY(i);
                if (mouseX >= x + 16 && mouseX <= x + PANEL_W - 16
                        && mouseY >= ry && mouseY <= ry + 28) {
                    toggle(i);
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void toggle(int i) {
        switch (i) {
            case 0 -> Settings.hud = !Settings.hud;
            case 1 -> Settings.hitParticles = !Settings.hitParticles;
            case 2 -> Settings.trail = !Settings.trail;
            case 3 -> Settings.accentIndex = (Settings.accentIndex + 1) % Settings.ACCENTS.length;
            default -> { }
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
