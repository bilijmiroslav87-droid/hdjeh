package com.glassmenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class GlassMenu implements ClientModInitializer {
    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.glassmenu.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
        ));

        // Open menu with key, and draw self-only trail
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new GlassScreen());
                }
            }
            if (Settings.trail && client.player != null && client.world != null
                    && client.world.getTime() % 2 == 0) {
                client.world.addParticle(ParticleTypes.END_ROD,
                        client.player.getX(), client.player.getY() + 0.1, client.player.getZ(),
                        0.0, 0.01, 0.0);
            }
        });

        // Burst of crit particles on the local client when you hit something
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (Settings.hitParticles && world.isClient() && entity != null) {
                double y = entity.getY() + entity.getHeight() * 0.5;
                for (int i = 0; i < 8; i++) {
                    world.addParticle(ParticleTypes.CRIT, entity.getX(), y, entity.getZ(),
                            (Math.random() - 0.5) * 0.3,
                            Math.random() * 0.3,
                            (Math.random() - 0.5) * 0.3);
                }
            }
            return ActionResult.PASS;
        });

        // Small HUD panel: time, FPS, coordinates
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            if (!Settings.hud) return;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;

            String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
            String fps = mc.getCurrentFps() + " fps";
            String pos = mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ();

            int x = 6, y = 6, w = 120, h = 40;
            ctx.fill(x, y, x + w, y + h, 0x88101820);
            ctx.fill(x, y, x + w, y + 1, Settings.accent());
            ctx.drawTextWithShadow(mc.textRenderer, time + "  " + fps, x + 6, y + 6, 0xFFFFFFFF);
            ctx.drawTextWithShadow(mc.textRenderer, pos, x + 6, y + 22, 0xFFBBBBBB);
        });
    }
}
